---
version: alpha
name: A3KDS
description: A3KDS. Modern editorial journal - calm surface, confident content.
colors:
  primary: "#0A6EC2"
  secondary: "#11C4D4"
  tertiary: "#BE3372"
  neutral: "#f7fafc"
  danger: "#C2410C"
  warning: "#8F5F18"
  success: "#237714"
typography:
  h1:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: "-0.02em"
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    lineHeight: 1.6
  code:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
rounded:
  sm: "16px"
  md: "16px"
  lg: "16px"
spacing:
  sm: "8px"
  md: "16px"
  lg: "24px"
components:
  button-primary:
    backgroundColor: "#0A6EC2"
    textColor: "#ffffff"
    rounded: "{rounded.sm}"
    padding: 12px
---

## Overview

A3KDS. Modern editorial journal: calm surface, confident content.
Chrome recedes; typographic hierarchy leads; density is a mode (comfortable/compact), not a compromise.

## Colors

- **Primary (#0A6EC2):** brand blue. One step serves every interactive role - action fills, link text, focus ring - because it clears AA both as a fill under white text and as text on every surface.
- **Tertiary (#BE3372):** pink accent - personality color, spent deliberately.
- **Semantic:** danger #C2410C, warning #8F5F18, success #237714 (all AA body on white).
- Mint (#4FE7AF) is data/accent fill only; never text on light surfaces.

## Typography

Inter everywhere (single family, weight and optical hierarchy doing the work); JetBrains Mono for code/data.
An 11-step rem scale (3xs-4xl) with nine semantic roles - display, h1-h3, body, bodySm, caption, eyebrow, code.
Components consume the roles, never the raw scale; a guardrail test fails the build on a hard-coded font-size.
Prose measure 45-75ch; tabular figures where numbers align.

## Layout

4px base grid. Two density modes: comfortable (reading) and compact (data).
Border-driven separation first; tint second; shadow last.

## Do's and Don'ts

- DO use sentence case everywhere. DON'T use Title Case or exclamation marks in system messages.
- DO spend pink/honey accents deliberately. DON'T spray them.
- DO respect prefers-reduced-motion. Entrances ease (~200ms); exits are instant.
- All interactive components define default/hover/focus-visible/active/disabled/loading states.
