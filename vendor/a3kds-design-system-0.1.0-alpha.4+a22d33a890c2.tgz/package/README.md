# @a3kds/design-system

Tokens and React components for Andrew's apps. Editorial-journal aesthetic:
calm surface, confident content. Token contrast and selected component behavior are
checked automatically; full WCAG 2.2 AA conformance is not established.

**Status: `0.1.0-alpha.4`.** Thirteen component families, published to the public npm registry from this repo only.
Not yet adopted by a consumer app — see [Status and honesty](#status-and-honesty).

---

## Structured usage documentation

The DSDS pilot covers Button, Modal, and split-view. Edit `docs/a3kds.dsds.yaml`;
`npm run build:docs` generates the shared artifact for the playground Guidance page
and MCP `get_documentation`. `npm run check:docs` validates schema, local references,
and freshness. See [the documentation workflow](docs/README.md).

## Install

Published to the public npm registry:

```bash
npm install @a3kds/design-system
```

Pin a specific prerelease: `npm install @a3kds/design-system@0.1.0-alpha.4`.

## Use

Two stylesheets, **tokens first**, then components:

```ts
import "@a3kds/design-system/tokens.css";
import "@a3kds/design-system/styles.css";

import { Button, Card, Badge } from "@a3kds/design-system";

export function Example() {
  return (
    <Card heading="Deploy status">
      <Badge tone="danger">Failed</Badge>
      <Button variant="primary" onClick={retry}>Retry</Button>
    </Card>
  );
}
```

Tokens are also available outside React — for a Tailwind `theme.extend`, an MUI
`createTheme`, or any non-React consumer:

```ts
import { lightColors, darkColors, primitives } from "@a3kds/design-system/tokens";

lightColors.action_primary; // "#0A6EC2"
primitives.space_4;         // "16px"
```

`@a3kds/design-system/tokens.dtcg.json` is the same set in W3C DTCG format
(`$value` / `$type`, fully resolved) for design-token tooling.

## Light and dark

`tokens.css` ships both modes. Dark applies automatically under
`prefers-color-scheme: dark`; either mode can be forced:

```html
<html data-mode="dark">
<html data-mode="light">
```

`data-mode="light"` is the one that used to be missing: a consumer on a dark-OS
machine rendered dark with no way back. Both explicit blocks are emitted *after*
the media query, because `[data-mode]` and `:root` have equal specificity and the
override is won on order, not weight — there is a test asserting that ordering.

Both modes pass the same contrast gate. Components never hardcode a foreground —
`action.primaryText` is a token, so the pairing follows the mode.

## Components

| Component | Notes |
| --- | --- |
| `Button` | `primary` / `secondary` / `ghost`; `loading` disables and sets `aria-busy` |
| `TextField`, `FormField` | label + control + hint/error, `aria-describedby` wired |
| `Card` | optional heading |
| `Badge` | `neutral` / `info` / `success` / `warning` / `danger` |
| `DataTable`, `List` | semantic `<table>` with `<caption>` and `scope="col"` |
| `ToastStack`, `toast` | polite region for status, assertive region for errors |
| `Skeleton` | decorative; `aria-hidden`, sits inside an `aria-busy` container |
| `NavBar` | `aria-current="page"` on the active link |
| `Tabs` | roving tabindex, Arrow/Home/End, automatic activation |
| `Modal` | `role="dialog"` + `aria-modal`, focus trap, Escape and backdrop close |
| `SearchFilter` | filter combobox with keyboard selection |
| `Container`, `Stack` | width/density wrapper and token-scale flex stack |
| `Grid`, `GridItem` | 16-column layout grid; tracks fold to 8 below 900px |
| `DetailPanel` | right-edge slide-out; `inert` when closed, not `aria-hidden` |
| `Select` | native `<select>` in field clothing, token-drawn caret |
| `ProgressBar` | determinate and indeterminate |

## Architecture

```
tokens/tokens.json      single source of truth for values
  └─ tokens/build.py    → dist/tokens.css   CSS custom properties (--a3kds-*), both modes
                        → dist/tokens.js|.d.ts|.ts   typed constants
                        → dist/tokens.dtcg.json      W3C DTCG
                        → DESIGN.md                  generated spec (never hand-edit)
layouts/templates.json  single source of truth for structure (page templates)
  └─ guardrails         → src/components/__guardrails__/layouts.test.ts
  └─ specimen           → src/playground/Layouts.tsx (rendered from the file)
src/                    components, one directory each, plain CSS
  └─ vite.lib.config.ts → dist/index.js + dist/styles.css
```

Three token tiers: **primitive** (raw scales, internal), **semantic**
(role names, per mode — what components consume), **component** (currently
empty).

Components consume semantic tokens only. A guardrail test fails the build on a
hardcoded hex, and a second one fails it when a `var(--a3kds-*)` reference does not
resolve in the emitted CSS.

The one exception is `--a3kds-local-*`, a reserved namespace for per-instance
plumbing a component sets on itself — `Grid` passes column placement that way so
its stylesheet keeps the last word over an inline `grid-column` shorthand. The
build never emits that prefix, so it cannot collide with a token, and a guardrail
requires every local property to carry a fallback.

### The pair rule

Every background token that can carry text has a paired foreground token —
`action.primary` / `action.primaryText`. This is load-bearing, not tidiness:
when the pairing was missing, `Button` hardcoded `color: #ffffff` because there
was no token to reach for, and the dark-mode button shipped at 2.13:1. Add a
fill, add its `*Text` partner.

### Typography

Three tiers, same shape as colour. An 11-step rem scale (`3xs`-`4xl`), plus
line-height, weight, and letter-spacing primitives; nine semantic roles on top:

| role | size | line-height | weight | tracking |
| --- | --- | --- | --- | --- |
| `display` | 2.25rem | 1.1 | 700 | -0.02em |
| `h1` | 1.75rem | 1.1 | 700 | -0.02em |
| `h2` | 1.375rem | 1.25 | 600 | 0 |
| `h3` | 1.125rem | 1.25 | 600 | 0 |
| `body` | 1rem | 1.6 | 400 | 0 |
| `bodySm` | 0.875rem | 1.5 | 400 | 0 |
| `caption` | 0.8125rem | 1.5 | 400 | 0 |
| `eyebrow` | 0.6875rem | 1.5 | 600 | 0.04em |
| `code` | 0.8125rem | 1.5 | 400 | 0 |

```css
font-size: var(--a3kds-typography-body-size);
line-height: var(--a3kds-typography-body-line-height);
```

Typography is mode-independent, so it is emitted once in `:root` and is absent
from the dark blocks.

The scale is `rem`, not `px`, so it honours the reader's browser font size
(WCAG 1.4.4). Steps were derived from what consumer apps actually used -
final-fantasy's 10 sizes and personal-recruiter's 13 - collapsed from 23 ad-hoc
values into 11. Adopting means snapping to the nearest step.

Components consume roles, never the raw scale, and a guardrail test fails the
build on a hard-coded `font-size`, `font-weight`, or `line-height`. That rule
exists because A3KDS itself shipped four unrelated magic sizes
(0.8125/0.9375/1/1.125rem) while telling consumers "typographic hierarchy leads".

### React Server Components (Next App Router)

The published bundle opens with a `"use client"` directive, so importing from
`@a3kds/design-system` inside a Next App Router app works from a Server
Component. Without it the import fails at build: `dist/index.js` is a single
module that imports `useState`, `useEffect`, `useId`, `useRef`, and
`createPortal` at the top, so even a `Badge`-only import pulls client-only React
APIs into the server graph.

The directive is inert for non-RSC bundlers (Vite, webpack) — verified against
the existing Vite consumers, which build unchanged.

**Consequence to know:** the whole bundle is a client module, so no A3KDS
component renders on the server, including presentational ones like `Card` and
`Badge`. Splitting into server-safe and client entrypoints would recover that;
it is not done yet. A guardrail test asserts the directive is the *first*
statement in the bundle — placed after an import it is only a string expression
and RSC ignores it.

### Page templates

`layouts/templates.json` records how screens are assembled: a template is a named
span recipe over the 16-column grid, with the regions it defines, the components
that occupy them, the overlay it supports, and the rules that govern it.

Templates are **data, not components**. Page composition is where apps legitimately
differ, so an `AppShell` export would be a straitjacket that every consumer needs
an escape hatch from — and the grid already gives you the primitive. Four templates
are recorded today, all at `specimen` status:

| id | shape | resolves |
| --- | --- | --- |
| `content-detail` | 11 + 5, then 8 + 4 + 4; `DetailPanel` covers the sidebar | detail that is occasional |
| `split-view` | 5 + 11, list beside a permanent detail pane | detail that is constant |
| `content-page` | `NavBar` + 8 + 8 at the comfortable measure | reading |
| `app-grid` | a row repeated per item, tiles of span 4 | a hub |

`content-detail` and `split-view` answer the same audited pattern two ways, which
is why `selectionDriven` is a declared field rather than inferred from whether a
template has an overlay: a split view is selection-driven and has none.

**Rows come in two kinds.** A fixed row names its regions and must fill exactly
one grid row. A row marked `repeat` renders once per item in a collection, so it
declares a single region whose span must divide the grid evenly, plus the
`minWidth` its tiles fold on. `app-grid` enumerated eight tiles before this
existed — describing a fixed eight-tile page that no consumer has, when a hub's
tile count comes from its data.

**The two kinds also fold differently**, and `fold.behaviour` has to say which:

| behaviour | below `maxWidth` | for |
| --- | --- | --- |
| `full-width` | each region takes the whole row, in order | page regions |
| `reflow` | tiles keep flowing at their `minWidth` | a run of equivalent things |

`Grid` takes `tiles` and `minTileWidth` to opt into the second. Both grids keep
the 16 columns at wide widths; only the fold differs. Folding tiles like regions
is a real regression — a hub whose tiles auto-filled two or three across at 900px
would drop to one the moment it moved onto `Grid`, burying the tenth tile. A
guardrail asserts the record and `grid.css` agree on which fold each template
gets.

`layouts.test.ts` holds the record to the code — eleven checks, each verified to
fail under mutation:

| Check | Catches |
| --- | --- |
| Rows fill exactly one grid row | A recipe whose spans don't add to 16 |
| `gridColumns` matches `primitive.grid.columns` | Retuning the grid without retuning the templates |
| Named components are exported | A template composing something unreachable |
| `fold.maxWidth` matches `grid.css` | The one hard-coded breakpoint drifting from the record |
| Overlay `covers` names a real region | An overlay pointing at nothing |
| `published` requires two consumers | Promotion by assertion |
| A repeating row has one region whose span divides the grid | A ragged final column at every width |
| `fold.behaviour` matches what `grid.css` does | A run of tiles described as stacking |
| The playground maps the file, never an id | The drawing diverging from the record |

Templates ship: `@a3kds/design-system/templates.json` resolves to
`layouts/templates.json`, and a guardrail checks that the export and the `files`
list agree, since an export pointing at an unshipped path resolves fine in the
repo and 404s for every consumer.

#### The layout scanner

`audit/scan_layouts.py` (`npm run scan:layouts`) catalogues screens across the
consumer repos the way `scan_architecture.py` catalogues stacks, and writes
`audit/layout-inventory.json`. Read-only: no scanned repo is modified.

```bash
npm run scan:layouts                      # write the inventory
python3 audit/scan_layouts.py --print     # summary only, no write
python3 audit/scan_layouts.py --sync      # write CONFIRMED consumers into templates.json
```

Matching compares a screen's source text against the **shape** of each record —
does the template want an overlay, navigation chrome, uniform tiles, a constrained
measure — so adding a template does not mean editing the scanner. No template id
appears in it.

Three properties are what make the output trustworthy rather than merely
plausible:

- **Only present structure is evidence.** Agreeing that a feature is *absent*
  from both a screen and a template says nothing. An earlier version scored it
  anyway and 82 of 102 screens came back "medium" on the strength of shared
  emptiness.
- **A screen is read together with what it imports**, one level deep. These apps
  build a screen as a shell that composes panes: `personal-recruiter`'s
  `dashboard/src/App.tsx` has no layout signal of its own and all of them in
  `PipelinePane/DetailDrawer.tsx`.
- **`confirmed` is never set by the scanner.** A human sets it after reading the
  `evidence` lines, and `--sync` writes `consumers` from confirmed entries only —
  so a heuristic can never satisfy the two-consumer promotion rule. Confirmations
  survive a rescan. Reaching two consumers prints an eligibility note; it does not
  change `status`, because promotion is a decision recorded in
  `audit/SELECTION.md`, exactly as it is for a component.

Today's run: 10 repos, 63 screen-shaped files, **0 confirmed**, so every template
is still `specimen` with no consumers. The candidates corroborate the human audit
independently — `one-portal/src/App.tsx` matches `app-grid` at 1.0 on
`<section className="grid">` plus `apps.map(…)`; `personal-recruiter` matches
`content-detail` on its `DetailDrawer` import; `remarkable-bridge`'s `LibraryView`
matches `split-view` on `<aside className="folder-pane">` beside `selectedId`.
Those are the two master-detail instances `ui-patterns.json` recorded by hand,
now separated by which way each one resolves.

Telling those two apart needed the `overlay` signal split in half. It originally
matched `<aside>` and `role="complementary"` as well, which are markers of a
*permanent* side region — so a side-by-side app read as an overlay app. Overlay
now means a surface that opens and closes (`DetailPanel`, `Drawer`,
`aria-expanded`, `isOpen`); `panes` means one that is always there.

## Accessibility gate

`tokens/validate_contrast.py` **derives** its checks from the token tree rather
than enumerating pairs:

| Rule | Check | Threshold |
| --- | --- | --- |
| R1/R2 | every `text.*` and `status.*Text` × every `surface.*` | 4.5:1 |
| R3 | `link`, `accent` × every `surface.*` | 4.5:1 |
| R4 | `action.<x>Text` × `action.<x>` and `<x>Hover` | 4.5:1 |
| R5 | `focusRing`, `border.strong`, `action.*` × every `surface.*` | 3:1 (SC 1.4.11) |

70 pairs at present. Adding a surface or a status role extends the set
automatically, so the gate cannot drift from the layer it guards — there is a
test asserting exactly that.

Checking foregrounds against *every* surface matters: colours tuned on white
lose roughly 0.5:1 on `surface.sunken`, which is enough to drop several below AA.

```bash
npm run contrast:report   # full matrix, for design review
```

Components additionally carry axe-core assertions. Note that jsdom has no
layout, so axe cannot verify colour contrast or focus visibility there — the
Python gate covers contrast, and focus visibility needs a real browser.

## Scripts

| Script | Does |
| --- | --- |
| `npm run check` | the merge gate: tokens → contrast → self-test → typecheck → tests → lib build |
| `npm run build` | tokens + library |
| `npm test` | 146 tests across 20 files |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run playground` | dev server on :5177 |
| `npm run contrast:report` | full contrast matrix |
| `npm run scan:layouts` | catalogue consumer screens into `audit/layout-inventory.json` |
| `npm run lint:design` | lint the generated `DESIGN.md` |

## Contributing a component

1. Write the tests first, naming the A2 acceptance clause each one covers.
2. Assert the property, not the mechanism. `role="alert"` being present is not
   the same as errors announcing assertively; a `<table>` existing is not the
   same as it being semantic. Mutate your implementation and confirm a test
   fails — several early tests passed against deliberately broken components.
3. Styles go in `<Component>/<component>.css`, semantic tokens only.
4. Export from `src/index.ts`; add the stylesheet to `src/styles.css`. A
   guardrail test fails if you forget either.
5. `npm run check` must be green.

Adding a **page template** is a different job: add it to `layouts/templates.json`
and nothing else — the specimen and the guardrails follow from the record. Leave
`consumers` empty and `status` at `specimen` until the layout scanner can confirm
otherwise.

## Status and honesty

Per the PRD's honesty rule, adoption is reported as-is:

- **Built:** 13 component families / 22 exports, 4 page templates, 146 tests,
  contrast gate green in both modes.
- **Published:** `0.1.0-alpha.4` is live on the public npm registry, with both
  `latest` and `alpha` pointing at it (2026-09-08). The originally attempted
  `alpha.0` was quarantined by npm's Aug-2026 bypass-2FA token restriction and is
  a dead tombstone.
  Verified against the tarball pulled back from the registry, not just the local
  build: `Stack` emits `var(--a3kds-space-${gap})` with zero unprefixed
  `--space-*` left, `tokens.css` carries both `[data-mode="light"]` and
  `[data-mode="dark"]`, `Grid` / `Select` / `DetailPanel` and the `data-tiles`
  fold are in `styles.css`, and `layouts/templates.json` ships with all four
  templates behind the `./templates.json` export.
  **`alpha.3` and earlier are defective** — they ship the broken `Stack`
  (`var(--space-${gap})`, which resolves to nothing) and have no light-mode
  block. Anything still pinned below `alpha.4` should move.
  Note: npm now refuses to publish a prerelease without an explicit
  `--tag`; `latest` was moved onto it deliberately with `npm dist-tag add`.
- **Adopted by:** one-portal. Was a surgical `Badge` swap; as of 2026-09-08 its
  hub renders the `app-grid` template end to end — `Container density="compact"`,
  three `Grid tiles` sections of span-4 `GridItem`s, tiles on `Card` — and its
  own stylesheet lost `.wrap`, `.grid` and the `.card` surface. That makes
  `app-grid` the first template with a consumer (`status: adopted`).
  one-portal depends on `^0.1.0-alpha.4` and installs it from the registry;
  its typecheck, lint and 60 tests pass against the published package.
- **Fixed 2026-09-08 (previously deferred):** explicit light mode. `tokens.css`
  now emits `[data-mode="light"]` and `[data-mode="dark"]` after the dark media
  query, so either mode can be forced. This unblocks one-portal's dark flip and
  the cross-app theme toggle — but only after a republish.
- **Fixed 2026-09-08:** `Stack` emitted `var(--space-N)`, which no artifact in
  the package defines, so every `Stack` gap silently resolved to nothing. The
  same typo was in the playground. Both fixed and covered by a regression test.
- **Not built:** docs site (Slice 4), consumer audit scanner (Slice 5). The
  component registry named in A2's contract does not exist, so A2 has no state
  and no signal.
- **Built 2026-09-08:** `audit/scan_layouts.py` and `audit/layout-inventory.json`.
  Nothing is confirmed in it yet, so no template has a consumer and none is
  eligible for promotion.
- **Known gaps:** the `component` token tier is empty; no elevation tier
  (the three shadows are still literals in component CSS); no breakpoint tokens
  (`Grid` carries the only hard-coded viewport width in the package, at 900px, and
  now folds two ways off it);
  density is a documented mode that only changes measure.
  - No icon system; no Checkbox, Radio, Switch, or Textarea; no CI; no CHANGELOG.
  - `Grid`, `DetailPanel` and `Select` have no consumer yet. `Select` overturns
    the selection memo's own ranking — the argument is written down in
    `audit/SELECTION.md`, not assumed.

See `PRD.md`, `AUDIT-v0.1.md`, and `audit/SELECTION.md` for how the component
set was chosen (306 catalogued UI instances across six repos, scored against a
rubric fixed before scoring).
