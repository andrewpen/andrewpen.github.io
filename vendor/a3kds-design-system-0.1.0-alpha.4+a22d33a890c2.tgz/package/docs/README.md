# A3KDS documentation pilot

Edit `a3kds.dsds.yaml`, then run `npm run build:docs`. Commit the generated `a3kds.docs.json` with the source. Both the playground Guidance page and MCP `get_documentation` read that artifact. Run `npm run check:docs` to validate the pinned DSDS 0.20.0 schema, IDs, local references, JSON pointers, linked automated checks, and artifact freshness. Validation runs offline using the vendored schema. External URLs are not fetched. This is a project-specific reference checker, not a claim of full upstream lint conformance.

The pilot covers Button, Modal, and split-view. YAML owns usage guidance and known limitations; React source owns APIs, tokens own values, and layouts/templates.json owns geometry and adoption. No duplicated prop tables or layout spans. Relative references are resolved from the authored YAML in this repository. This pilot is repository documentation, not an npm export with broken source links.

Requirements describe intended behavior. `checkedBy: automated` means a check is linked, not that its latest execution passed. Do not add review dates or successful verification claims without an actual review or run. Known limitations must remain visible to both people and agents.

To extend: add an entry, link its source and real checks, generate, and validate. Schema upgrades are explicit: vendor a reviewed version, update the version check, then rerun the checks. Do not manually edit the generated JSON. The existing DESIGN.md remains generated token documentation; this pilot does not replace it.

## Website convergence project

The [project plan and seven briefs](projects/website-convergence/README.md) define the staged path from the DSDS pilot to a released design system powering the website. They include activity assignments, acceptance criteria, an activity ledger, and a future backlog.
